#include <bits/stdc++.h>
using namespace std;

int main() {
	set<int> s;
	s.insert(2);
	s.insert(4);
	s.insert(6);
	auto it=s.find(4);
	cout << *(it) << endl;
	cout << *(--it) << endl;
}
