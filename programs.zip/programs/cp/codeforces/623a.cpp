#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
    
}