#include<bits/stdc++.h>
using namespace std;

class Solution {
public:
    string getHappyString(int n, int k) {
      vector<string> * old = new vector<string>();
      old->push_back("a");
      old->push_back("b");
      old->push_back("c");
      vector<string>* neu = new vector<string>();
      for(int i=2; i<=n; i++) {
        for(char ch = 'a'; ch!='d'; ch++) {
          for(int j=0; j<old->size(); j++) {
            if((old->at(j))[0]==ch) continue;
            neu->push_back(ch+(old->at(j)));
          }
        }
        swap(old,neu);
        neu->clear();
      }
      if(old->size()<k) return "";
      return old->at(k-1);
    }
};