for i in range(30):
    print(7*i)
