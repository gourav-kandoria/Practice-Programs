var x = document.getElementsByClassName("tag-box");
x[0].parentNode.parentNode.remove();
